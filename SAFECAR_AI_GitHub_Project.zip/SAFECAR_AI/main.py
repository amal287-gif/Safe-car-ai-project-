"""
SAFECAR AI - Vehicle Safety Analyzer
Educational software prototype using simulated vehicle readings.

This program is NOT a certified diagnostic, legal, or safety device.
It does not connect to a real vehicle or determine whether a vehicle is roadworthy.
"""

import csv
from dataclasses import dataclass
from pathlib import Path


@dataclass
class VehicleReading:
    vehicle_id: str
    engine_temp_c: float
    tire_pressure_psi: float
    battery_voltage: float
    driving_hours: float
    warning_light: bool


def assess_vehicle(reading: VehicleReading) -> dict:
    """Assess sample readings using transparent demonstration thresholds."""
    findings = []

    if reading.engine_temp_c >= 110:
        findings.append(("High engine temperature", "high"))
    elif reading.engine_temp_c >= 100:
        findings.append(("Engine temperature is elevated", "moderate"))

    if reading.tire_pressure_psi < 28 or reading.tire_pressure_psi > 36:
        findings.append(("Tire pressure is outside the example range", "moderate"))

    if reading.battery_voltage < 11.8:
        findings.append(("Battery voltage is low", "moderate"))

    if reading.driving_hours >= 9:
        findings.append(("Driving-time threshold reached in this demonstration", "high"))
    elif reading.driving_hours >= 7:
        findings.append(("Consider taking a rest break", "moderate"))

    if reading.warning_light:
        findings.append(("Vehicle warning indicator reported", "moderate"))

    if any(level == "high" for _, level in findings):
        risk = "HIGH"
    elif findings:
        risk = "MODERATE"
    else:
        risk = "LOW"

    return {"risk": risk, "findings": findings}


def load_readings(csv_path: Path) -> list[VehicleReading]:
    readings = []
    with csv_path.open("r", newline="", encoding="utf-8") as file:
        for row in csv.DictReader(file):
            readings.append(
                VehicleReading(
                    vehicle_id=row["vehicle_id"],
                    engine_temp_c=float(row["engine_temp_c"]),
                    tire_pressure_psi=float(row["tire_pressure_psi"]),
                    battery_voltage=float(row["battery_voltage"]),
                    driving_hours=float(row["driving_hours"]),
                    warning_light=row["warning_light"].strip().lower() == "true",
                )
            )
    return readings


def print_report(reading: VehicleReading) -> None:
    result = assess_vehicle(reading)
    print("\n" + "=" * 48)
    print(f"SAFECAR AI | Vehicle: {reading.vehicle_id}")
    print("=" * 48)
    print(f"Engine temperature : {reading.engine_temp_c:.1f} °C")
    print(f"Tire pressure      : {reading.tire_pressure_psi:.1f} PSI")
    print(f"Battery voltage    : {reading.battery_voltage:.1f} V")
    print(f"Driving duration   : {reading.driving_hours:.1f} hours")
    print(f"Warning indicator  : {'Yes' if reading.warning_light else 'No'}")
    print(f"\nDEMO RISK LEVEL: {result['risk']}")

    if result["findings"]:
        print("\nFindings:")
        for description, level in result["findings"]:
            print(f" - [{level.upper()}] {description}")
    else:
        print("\nNo issues were flagged by the demonstration rules.")

    print("\nImportant: This is an educational prototype using sample data.")
    print("It cannot diagnose a real vehicle or determine legal compliance.")


def main() -> None:
    sample_file = Path(__file__).parent / "sample_data.csv"
    readings = load_readings(sample_file)

    print("Welcome to SAFECAR AI")
    print("Demonstration vehicle safety analysis")
    for reading in readings:
        print_report(reading)


if __name__ == "__main__":
    main()
