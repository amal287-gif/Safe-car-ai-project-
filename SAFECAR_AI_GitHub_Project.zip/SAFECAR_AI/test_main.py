import unittest
from main import VehicleReading, assess_vehicle


class SafetyAnalyzerTests(unittest.TestCase):
    def test_low_risk_reading(self):
        reading = VehicleReading("TEST-1", 90, 33, 12.5, 2, False)
        self.assertEqual(assess_vehicle(reading)["risk"], "LOW")

    def test_high_temperature_flags_high_risk(self):
        reading = VehicleReading("TEST-2", 115, 33, 12.5, 2, False)
        self.assertEqual(assess_vehicle(reading)["risk"], "HIGH")

    def test_long_driving_time_flags_high_risk(self):
        reading = VehicleReading("TEST-3", 90, 33, 12.5, 9, False)
        self.assertEqual(assess_vehicle(reading)["risk"], "HIGH")

    def test_moderate_tire_pressure_finding(self):
        reading = VehicleReading("TEST-4", 90, 25, 12.5, 2, False)
        result = assess_vehicle(reading)
        self.assertEqual(result["risk"], "MODERATE")
        self.assertTrue(any("Tire pressure" in item[0] for item in result["findings"]))


if __name__ == "__main__":
    unittest.main()
