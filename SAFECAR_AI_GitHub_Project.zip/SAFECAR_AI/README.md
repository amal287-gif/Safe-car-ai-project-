# SAFECAR AI – Vehicle Safety Analyzer

**An educational prototype concept for AI-assisted vehicle safety inspection.**

## Project overview
SAFECAR AI explores how software could help organize vehicle safety information and highlight readings that may deserve attention. This first prototype analyzes **simulated sample readings** using transparent, rule-based checks.

It is inspired by the broader SAFECAR AI concept: a future inspection platform for conventional, hybrid, and electric vehicles at fuel and charging stations.

## What this prototype does
- Reads sample vehicle data from a CSV file.
- Checks example engine-temperature, tire-pressure, battery-voltage, and driving-duration thresholds.
- Notes whether a warning indicator was reported.
- Produces a LOW, MODERATE, or HIGH demonstration risk category.
- Includes automated unit tests.

## Important limitations
- This version is **not a machine-learning model**; it uses simple demonstration rules.
- All readings in `sample_data.csv` are fictional examples.
- It does not connect to a real vehicle, OBD-II port, driver account, or charging station.
- Thresholds are illustrative software-demo values, not manufacturer specifications or legal limits.
- A result must never be used to decide whether a real vehicle is safe to drive or whether a driver has broken the law.
- Real deployment would require validated automotive data, manufacturer/vehicle compatibility, professional testing, privacy safeguards, and regulatory approval.

## Requirements
- Python 3.9 or newer
- No external packages required

## Run the program
Open a terminal in this folder and run:

```bash
python main.py
```

The program reads `sample_data.csv` and prints a report for each example vehicle.

## Run the tests

```bash
python -m unittest -v
```

## Project structure

```text
SAFECAR_AI/
├── main.py
├── sample_data.csv
├── test_main.py
├── README.md
└── .gitignore
```

## Future research directions
1. Explore computer vision for identifying visible underbody anomalies.
2. Investigate safe, authorized access to vehicle diagnostic data.
3. Study electric-vehicle battery health indicators.
4. Evaluate anomaly-detection methods using a properly sourced and labeled dataset.
5. Design privacy-preserving driver fatigue and driving-time features.

## Author
Add your name here.

## Project status
Concept-stage educational prototype. The full SAFECAR AI station has not been built or validated.
